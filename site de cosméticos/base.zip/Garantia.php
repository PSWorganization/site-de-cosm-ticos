<?php
include_once("header.php");
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nós</title>
    <link rel="stylesheet" href="floralbeauty.css">
</head>
<body>

    <div class="login-cadastro-container">
        <div class="sobre-container">
            <h2>Garantia Flora Beauty</h2>
           <ol>
             <h3>O que é a Garantia Flora Beauty?</h3>
            <p>A Garantia Flora Beauty oferece proteção e assegura o recebimento e a qualidade do produto comprado,
            facilitando o processo de reembolso caso haja contratempos.</p>
            <h4>1) Extensão da garantia para pedido não enviados</h4>
            <p>Os vendedores devem garantir o envio dentro do período de Garantia Shopee; caso contrário, o pagamento será automaticamente reembolsado.
             Se o vendedor ainda não enviou sua compra e você deseja dá-lo mais tempo para fazer o envio.</p>
            <h4>2) Extensão da Garantia Shopee após entrega do produto</h4>
            <p>O período de garantia é de 7 dias após o recebimento do produto.
             É possível estendê-la por mais 3 dias depois da entrega, totalizando 10 dias de garantia do seu pedido.</p>
           <h5>O que você, visitante, pode fazer aqui?</h5>
            <p>Nossa plataforma oferece segurança total dos dados coletados. Além de realizar suas compras, você tem a oportunidade de se cadastrar como vendedor e expandir seu próprio negócio.</p>
        </ol>
        </div>
    </div>
    
</body>
</html>
<?php
include_once("footer.php");
?>