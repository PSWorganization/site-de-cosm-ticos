<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="floralbeauty.css">
</head>
<body>

<footer class="fundo-azul">
        <div class="conteudointerno conteudodofooter">
            <div class="duvidas">
            <h3>Atendimento ao Cliente</h3>
                <ul>
                    <li>
                        <a href="#">Como Comprar</a></li>
                    <li>
                        <a href="#">Métodos de Pagamento</a></li>
                    <li>
                        <a href="#">Devolução e Reembolso</a></li>
                    <li>
                        <a href="Garantia.php">Garantia Flora Beauty</a></li>
                </ul>


            </div>
<div class="sobrenos">
<div class="titulo">
            <h1 id="rodape">Flora Beauty</h1>
        </div>
       <p> Nosso objetivo é espalhar o autocuidado pelo mundo. <br> Compra e venda de cosméticos 
       por um preço querido, no conforto de sua casa!</p>

</div>
            <div class="pagamentos">
                <h3>Formas de Pagamento </h3>
                <div>
                    <img src="pagamento.png" alt="mastercard">
                    <img src="pix.png" alt="pix">
                    <img src="boleto.png" alt="boleto">
                    <img src="hipercard.png" alt="hipercard">
                </div>
            </div>

            
        </div>
        <div class="linhadois"></div>
        <div class="copyright">
        <p >&copy; 2024 Flora Beauty. Todos os direitos reservados.</p>
    </div>
    </footer>
</body>
</html>