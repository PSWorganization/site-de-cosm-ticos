<?php
include_once("header.php");
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre Nós</title>
    <link rel="stylesheet" href="floralbeauty.css">
</head>
<body>

    <div class="escolha-produto">
       <p>lorem20000000000000</p>
    </div>
    
</body>
</html>
<?php
include_once("footer.php");
?>